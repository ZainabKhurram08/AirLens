import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

def show(df):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:1.5rem;">🤖 Predictive Modeling</h1>', unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">Linear Model: PM2.5 vs AQI</h3>', unsafe_allow_html=True)
        X_simple = df[['PM2.5']]
        y = df['AQI']
        model_simple = LinearRegression()
        model_simple.fit(X_simple, y)
        fig_simple = px.scatter(df, x='PM2.5', y='AQI', trendline="ols", 
                                template="plotly_white",
                                color_discrete_sequence=['#818cf8'])
        fig_simple.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig_simple, use_container_width=True)
        st.code(f"AQI = {model_simple.coef_[0]:.2f} × PM2.5 + {model_simple.intercept_:.2f}", language="python")
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">Multivariate Accuracy (PM2.5, NO2, CO)</h3>', unsafe_allow_html=True)
        features = ['PM2.5', 'NO2', 'CO']
        X_multi = df[features]
        model_multi = LinearRegression()
        model_multi.fit(X_multi, y)
        y_pred_multi = model_multi.predict(X_multi)
        r2 = r2_score(y, y_pred_multi)
        rmse = np.sqrt(mean_squared_error(y, y_pred_multi))
        mae = mean_absolute_error(y, y_pred_multi)
        m1, m2, m3 = st.columns(3)
        m1.metric("Precision (R²)", f"{r2:.2%}")
        m2.metric("RMSE", f"{rmse:.2f}")
        m3.metric("MAE", f"{mae:.2f}")
        r_col1, r_col2 = st.columns(2)
        with r_col1:
            st.markdown('<h4 style="color:#475569; font-weight:600; margin-top:1rem;">Residual Analysis</h4>', unsafe_allow_html=True)
            residuals = y - y_pred_multi
            fig_res = px.scatter(x=y_pred_multi, y=residuals, labels={'x': 'Predicted AQI', 'y': 'Residuals'},
                                 template="plotly_white", color_discrete_sequence=['#f43f5e'])
            fig_res.add_hline(y=0, line_dash="dash", line_color="black")
            fig_res.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=300)
            st.plotly_chart(fig_res, use_container_width=True)
            st.caption("🔍 **Interpretation:** A random spread of residuals around zero indicates a well-fit linear model (Homoscedasticity).")
        with r_col2:
            st.markdown('<h4 style="color:#475569; font-weight:600; margin-top:1rem;">Error Distribution</h4>', unsafe_allow_html=True)
            fig_err = px.histogram(residuals, nbins=30, template="plotly_white", color_discrete_sequence=['#818cf8'])
            fig_err.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', showlegend=False, height=300)
            st.plotly_chart(fig_err, use_container_width=True)
            st.caption("🔍 **Interpretation:** A bell-shaped curve indicates that prediction errors are normally distributed, confirming model reliability.")
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">🔮 Live Forecast Tool</h3>', unsafe_allow_html=True)
        st.markdown("Adjust the environmental factors below to instantly predict the Air Quality Index.")
        with st.form("prediction_form"):
            p1, p2, p3 = st.columns(3)
            val_pm = p1.slider("Current PM2.5", min_value=0.0, max_value=500.0, value=50.0)
            val_no2 = p2.slider("Current NO2", min_value=0.0, max_value=200.0, value=20.0)
            val_co = p3.slider("Current CO", min_value=0.0, max_value=2000.0, value=500.0, step=10.0)
            submitted = st.form_submit_button("Generate Forecast")
            if submitted:
                pred = model_multi.predict([[val_pm, val_no2, val_co]])[0]
                status_color = "#10b981" if pred <= 100 else "#f59e0b" if pred <= 150 else "#ef4444"
                st.markdown(f"""
                    <div style="background: {status_color}15; padding: 20px; border-radius: 20px; border: 2.5px solid {status_color}; text-align: center; margin: 20px auto; max-width: 300px; box-shadow: 0 10px 20px rgba(0,0,0,0.05);">
                        <p style="margin:0; color:{status_color}; font-weight:800; letter-spacing:1px; text-transform:uppercase; font-size:0.8rem;">ESTIMATED AQI</p>
                        <h1 style="margin:0; color:#1e1b4b; font-size:3.5rem; font-weight:900;">{pred:.1f}</h1>
                    </div>
                """, unsafe_allow_html=True)
