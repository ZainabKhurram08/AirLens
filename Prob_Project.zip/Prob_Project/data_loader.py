import pandas as pd
import numpy as np
import os

def get_data():
    filename = "pakistan_air_quality_final_clean.csv"
    if os.path.exists(filename):
        df = pd.read_csv(filename)
        column_map = {
            'timestamp': 'Date',
            'city': 'City',
            'pm10': 'PM10',
            'pm2_5': 'PM2.5',
            'carbon_monoxide': 'CO',
            'nitrogen_dioxide': 'NO2',
            'ozone': 'O3'
        }
        df = df.rename(columns=column_map)
        df['Date'] = pd.to_datetime(df['Date'])
        
        def calculate_aqi(pm25):
            if pm25 <= 12: return (50/12) * pm25
            elif pm25 <= 35.4: return ((100-51)/(35.4-12.1)) * (pm25-12.1) + 51
            elif pm25 <= 55.4: return ((150-101)/(55.4-35.5)) * (pm25-35.5) + 101
            elif pm25 <= 150.4: return ((200-151)/(150.4-55.5)) * (pm25-55.5) + 151
            elif pm25 <= 250.4: return ((300-201)/(250.4-150.5)) * (pm25-150.5) + 201
            else: return ((500-301)/(500.4-250.5)) * (pm25-250.5) + 301

        if 'AQI' not in df.columns:
            df['AQI'] = df['PM2.5'].apply(calculate_aqi)
        for col in ['PM2.5', 'PM10', 'NO2', 'CO', 'O3']:
            if col not in df.columns:
                df[col] = 0.0
        df = df.dropna(subset=['AQI', 'PM2.5', 'PM10', 'NO2', 'CO', 'O3'])
        return df
    
    return pd.DataFrame()

if __name__ == "__main__":
    df = get_data()
    print(f"Data loaded: {len(df)} rows")
