import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy import stats

def show(df, selected_pollutant):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:1.5rem;">🎲 Probability & Risk</h1>', unsafe_allow_html=True)
    with st.container(border=True):
        city = st.selectbox("Select City for Risk Profile", df['City'].unique())
        data = df[df['City'] == city][selected_pollutant].dropna()
        if len(data) < 2:
            st.warning("⚠️ Not enough data to calculate probabilities.")
            return
        col1, col2 = st.columns(2)
        mu, std = stats.norm.fit(data)
        x = np.linspace(min(data)-20, max(data)+20, 100)
        pdf = stats.norm.pdf(x, mu, std)
        cdf = stats.norm.cdf(x, mu, std)
        with col1:
            st.markdown(f'<h3 style="color:#475569; font-weight:700;">Density Curve (PDF) - {selected_pollutant}</h3>', unsafe_allow_html=True)
            fig_pdf = go.Figure()
            fig_pdf.add_trace(go.Scatter(x=x, y=pdf, mode='lines', fill='tozeroy', line=dict(color='#818cf8', width=3)))
            fig_pdf.update_layout(template="plotly_white", paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=10, b=10))
            st.plotly_chart(fig_pdf, use_container_width=True)
        with col2:
            st.markdown(f'<h3 style="color:#475569; font-weight:700;">Cumulative Curve (CDF) - {selected_pollutant}</h3>', unsafe_allow_html=True)
            fig_cdf = go.Figure()
            fig_cdf.add_trace(go.Scatter(x=x, y=cdf, mode='lines', line=dict(color='#2dd4bf', width=3)))
            fig_cdf.update_layout(template="plotly_white", paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=10, b=10))
            st.plotly_chart(fig_cdf, use_container_width=True)
    with st.container(border=True):
        st.markdown(f'<h3 style="color:#475569; font-weight:700;">Risk Probabilities for {selected_pollutant}</h3>', unsafe_allow_html=True)
        prob_list = []
        for city_name in df['City'].unique():
            city_data = df[df['City'] == city_name][selected_pollutant].dropna()
            if len(city_data) < 2: continue
            c_mu, c_std = stats.norm.fit(city_data)
            p_gt_150 = 1 - stats.norm.cdf(150, c_mu, c_std)
            p_gt_200 = 1 - stats.norm.cdf(200, c_mu, c_std)
            p_lt_50 = stats.norm.cdf(50, c_mu, c_std)
            prob_list.append({
                "City": city_name,
                "P(Value > 150)": p_gt_150,
                "P(Value > 200)": p_gt_200,
                "P(Value < 50)": p_lt_50
            })
        if prob_list:
            prob_df = pd.DataFrame(prob_list)
            styled_df = prob_df.style.format({
                "P(Value > 150)": "{:.2%}",
                "P(Value > 200)": "{:.2%}",
                "P(Value < 50)": "{:.2%}"
            }).background_gradient(cmap='Purples', subset=['P(Value > 150)', 'P(Value > 200)'])
            st.dataframe(styled_df, use_container_width=True)
        p_gt_200_selected = 1 - stats.norm.cdf(200, mu, std)
        if p_gt_200_selected > 0.05:
            st.error(f"🚨 **High Alert for {city}:** The probability of experiencing critical {selected_pollutant} levels (>200) exceeds 5%.")
        else:
            st.success(f"✅ **Status for {city}:** The probability of critical {selected_pollutant} levels is within safe academic margins (<5%).")
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">Normality Assessment</h3>', unsafe_allow_html=True)
        (osm, osr), (slope, intercept, r) = stats.probplot(data, dist="norm")
        fig_qq = go.Figure()
        fig_qq.add_trace(go.Scatter(x=osm, y=osr, mode='markers', marker=dict(color='#38bdf8')))
        fig_qq.add_trace(go.Scatter(x=osm, y=slope*osm + intercept, mode='lines', line=dict(color='#f43f5e', dash='dash')))
        fig_qq.update_layout(template="plotly_white", paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig_qq, use_container_width=True)
        observed, bin_edges = np.histogram(data, bins=10)
        expected = len(data) * np.diff(stats.norm.cdf(bin_edges, mu, std))
        expected = expected * (sum(observed) / sum(expected))
        chi_stat, p_val = stats.chisquare(observed, f_exp=expected)
        st.info(f"📊 **Hypothesis Test (Chi-Square)**: {'Normal' if p_val > 0.05 else 'Skewed'} (P-Value: {p_val:.4f})")
