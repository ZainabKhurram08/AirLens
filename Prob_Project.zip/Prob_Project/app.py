import streamlit as st
import pandas as pd
from data_loader import get_data
import os

st.set_page_config(
    page_title="AirLens | Air Quality Analysis",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

def inject_custom_css():
    css = """<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800;900&display=swap');
* { font-family: 'Outfit', sans-serif; box-sizing: border-box; }

[data-testid="stAppViewContainer"] {
    background: linear-gradient(135deg, #e2d1f9 0%, #f0ebff 50%, #d4c4fb 100%);
    min-height: 100vh;
}
[data-testid="stHeader"] { background-color: transparent !important; }

[data-testid="stSidebar"] {
    background: rgba(255, 255, 255, 0.4) !important;
    backdrop-filter: blur(15px) !important;
    border-right: 1px solid rgba(255,255,255,0.6) !important;
}
[data-testid="stSidebar"] [data-testid="stVerticalBlock"] {
    padding-top: 0rem !important;
    gap: 1.2rem !important;
}
[data-testid="stSidebar"] * { color: #4c1d95 !important; }
[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3 { color: #3b0764 !important; }
[data-testid="stSidebar"] [data-testid="stExpander"] {
    background: rgba(255,255,255,0.6) !important;
    border: 1px solid rgba(255,255,255,0.8) !important;
    border-radius: 12px !important;
    margin-bottom: 8px;
}
[data-testid="stSidebar"] [data-testid="stExpander"] summary {
    color: #6d28d9 !important;
    font-weight: 700 !important;
}
[data-testid="stSidebar"] [data-baseweb="select"] > div,
[data-testid="stSidebar"] [data-baseweb="input"] > div {
    background: rgba(255,255,255,0.8) !important;
    border: 1px solid rgba(255,255,255,0.8) !important;
    border-radius: 8px !important;
    color: #4c1d95 !important;
}
[data-testid="stSidebar"] [data-testid="stMetric"] {
    background: rgba(255, 255, 255, 0.6) !important;
    backdrop-filter: blur(10px) !important;
    padding: 15px !important;
    border-radius: 20px !important;
    box-shadow: 0 4px 15px rgba(109, 40, 217, 0.05) !important;
    border: 1px solid rgba(255,255,255,0.8) !important;
    transition: all 0.3s ease !important;
}
[data-testid="stSidebar"] [data-testid="stMetric"]:hover {
    background: rgba(255, 255, 255, 0.8) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 25px rgba(109, 40, 217, 0.1) !important;
}
[data-testid="stSidebar"] [data-testid="stMetricValue"] {
    color: #4338ca !important;
    font-size: 1.6rem !important;
    font-weight: 800 !important;
}
[data-testid="stSidebar"] [data-testid="stMetricLabel"] { 
    color: #6366f1 !important; 
    font-weight: 700 !important; 
    text-transform: uppercase !important;
    letter-spacing: 1px !important;
    font-size: 0.65rem !important;
}
[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,0.2) !important; margin: 2rem 0 !important; }

[data-testid="stSidebar"] [data-testid="stRadio"] label {
    display: flex !important;
    align-items: center !important;
    padding: 8px 14px !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
    font-size: 0.92rem !important;
    transition: background 0.2s ease !important;
    cursor: pointer !important;
}
[data-testid="stSidebar"] [data-testid="stRadio"] label:hover {
    background: rgba(255, 255, 255, 0.4) !important;
}
[data-testid="stSidebar"] [data-testid="stRadio"] [aria-checked="true"] + div label,
[data-testid="stSidebar"] [data-testid="stRadio"] input:checked ~ label {
    background: rgba(255, 255, 255, 0.8) !important;
    color: #3b0764 !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"],
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stSegmentedControl"],
[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] {
    background: linear-gradient(135deg, rgba(109,40,217,0.12) 0%, rgba(255,255,255,0.55) 100%) !important;
    backdrop-filter: blur(16px) !important;
    padding: 18px 28px !important;
    border-radius: 28px !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 10px !important;
    box-shadow: 0 8px 32px rgba(109,40,217,0.15), 0 2px 8px rgba(255,255,255,0.6) inset !important;
    margin-bottom: 32px !important;
    border: 1.5px solid rgba(255,255,255,0.85) !important;
    width: 100% !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] > div {
    display: flex !important;
    gap: 10px !important;
    justify-content: center !important;
    align-items: center !important;
    flex-wrap: nowrap !important;
    width: 100% !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button {
    border-radius: 50px !important;
    padding: 14px 22px !important;
    border: 2px solid rgba(255,255,255,0.7) !important;
    background: rgba(255,255,255,0.55) !important;
    color: #4c1d95 !important;
    transition: all 0.28s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
    backdrop-filter: blur(6px) !important;
    cursor: pointer !important;
    height: 56px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-shrink: 0 !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label *,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button * {
    font-size: 1.05rem !important;
    font-weight: 700 !important;
    color: inherit !important;
    margin: 0 !important;
    white-space: nowrap !important;
    letter-spacing: 0.3px !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label:hover,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button:hover {
    background: rgba(255,255,255,0.95) !important;
    border-color: #c4b5fd !important;
    transform: translateY(-4px) scale(1.06) !important;
    box-shadow: 0 10px 25px rgba(109,40,217,0.2), 0 0 12px rgba(255,255,255,0.8) !important;
    color: #3b0764 !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label:active,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button:active {
    transform: translateY(2px) scale(0.95) !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label[data-checked="true"],
[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label:has(input:checked),
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[aria-pressed="true"],
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[aria-selected="true"],
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[data-checked="true"] {
    background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%) !important;
    color: #ffffff !important;
    border-color: #7c3aed !important;
    box-shadow: 0 8px 24px rgba(109,40,217,0.45), 0 0 0 3px rgba(196,181,253,0.5) !important;
    transform: translateY(-3px) scale(1.05) !important;
}

[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label[data-checked="true"] *,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] [role="radiogroup"] label:has(input:checked) *,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[aria-pressed="true"] *,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[aria-selected="true"] *,
[data-testid="stAppViewContainer"] section[data-testid="stMain"] div[data-testid="stPills"] button[data-checked="true"] * {
    color: #ffffff !important;
    font-weight: 800 !important;
}

div[data-testid="stPills"] button:active, 
div[data-testid="stPills"] button:focus,
div[data-testid="stPills"] button[aria-selected="true"] {
    border-color: #7c3aed !important;
    color: #ffffff !important;
}

.status-pill { padding: 4px 12px; border-radius: 100px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }

[data-testid="stMain"] [data-testid="stMetric"] {
    background: rgba(255, 255, 255, 0.7) !important;
    backdrop-filter: blur(10px) !important;
    padding: 20px !important;
    border-radius: 20px !important;
    border: 1px solid rgba(255, 255, 255, 0.8) !important;
    box-shadow: 0 4px 15px rgba(109, 40, 217, 0.05) !important;
}
[data-testid="stMain"] [data-testid="stMetricLabel"] {
    color: #4338ca !important;
    font-weight: 700 !important;
    font-size: 0.85rem !important;
}
[data-testid="stMain"] [data-testid="stMetricValue"] {
    color: #1e1b4b !important;
    font-size: 2.2rem !important;
    font-weight: 900 !important;
}

[data-testid="stMain"] [data-testid="stExpander"],
[data-testid="stMain"] div[data-testid="stVerticalBlock"] > div[style*="border: 1px solid"] {
    background: rgba(255, 255, 255, 0.5) !important;
    backdrop-filter: blur(12px) !important;
    border: 1px solid rgba(255, 255, 255, 0.8) !important;
    border-radius: 24px !important;
    padding: 24px !important;
    box-shadow: 0 10px 30px rgba(109, 40, 217, 0.04) !important;
    margin-bottom: 20px !important;
}

[data-testid="stMain"] h1 { color: #1e1b4b !important; letter-spacing: -1.5px !important; font-weight: 900 !important; }
[data-testid="stMain"] h2, [data-testid="stMain"] h3 { color: #312e81 !important; letter-spacing: -0.5px !important; font-weight: 800 !important; }

[data-testid="stStatusWidget"] { display: none !important; }
.stProgress { display: none !important; }
div[data-testid="stDecoration"] { display: none !important; }
.stAppDeployButton { display: none !important; }
</style>"""
    st.markdown(css, unsafe_allow_html=True)

inject_custom_css()

df = get_data()

st.sidebar.markdown("""
<div style="text-align:center; padding: 20px 15px; background: rgba(255,255,255,0.1); border-radius: 25px; margin-bottom: 0px; border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(10px);">
    <div style="font-size:3.5rem; margin-bottom: 10px;">🌍</div>
    <div style="font-size:2.2rem; font-weight:900; color:#1e1b4b; letter-spacing:-1.5px; line-height:1;">AirLens</div>
    <div style="font-size:0.75rem; font-weight:800; color:#4338ca; text-transform:uppercase; letter-spacing:3px; margin-top:8px; opacity:0.8;">Precision Analytics</div>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown('<div style="margin-top: -10px;"></div>', unsafe_allow_html=True)
c1, c2 = st.sidebar.columns(2)
c1.metric("Cities", len(df['City'].unique()))
c2.metric("Records", f"{len(df):,}")

st.sidebar.markdown("---")

with st.sidebar.expander("🗺️ Region Filter", expanded=True):
    selected_cities = st.multiselect(
        "Select Cities",
        options=df['City'].unique(),
        default=df['City'].unique(),
        label_visibility="collapsed"
    )

with st.sidebar.expander("📅 Time Range", expanded=True):
    date_range = st.date_input(
        "Date Range",
        [df['Date'].min(), df['Date'].max()],
        label_visibility="collapsed"
    )

with st.sidebar.expander("🔬 Pollutant Focus", expanded=True):
    selected_pollutant = st.selectbox(
        "Pollutant",
        ["PM2.5", "PM10", "NO2", "CO", "O3"],
        label_visibility="collapsed"
    )
    
    pollutant_info = {
        "PM2.5": "Fine particulate matter — most dangerous to lungs",
        "PM10": "Coarse particulate matter — affects breathing",
        "NO2": "Nitrogen dioxide — from vehicle emissions",
        "CO": "Carbon monoxide — combustion byproduct",
        "O3": "Ozone — ground-level air pollutant"
    }
    st.markdown(f'<p style="font-size:0.78rem; color:#c4b5fd; margin-top:6px;">ℹ️ {pollutant_info[selected_pollutant]}</p>', unsafe_allow_html=True)

page = st.pills(
    "Navigation",
    ["🏠 Dashboard", "📊 Charts", "📈 Statistics", "🎲 Probability", "🤖 Regression", "🔗 Correlation"],
    default="🏠 Dashboard",
    label_visibility="collapsed"
)

page_map = {
    "🏠 Dashboard": "Dashboard",
    "📊 Charts": "Charts",
    "📈 Statistics": "Statistics",
    "🎲 Probability": "Probability",
    "🤖 Regression": "Regression",
    "🔗 Correlation": "Correlation"
}
if not page:
    page = "Dashboard"
else:
    page = page_map.get(page, "Dashboard")

if isinstance(date_range, (list, tuple)) and len(date_range) == 2:
    filtered_df = df[
        (df['City'].isin(selected_cities)) & 
        (df['Date'].dt.date >= date_range[0]) & 
        (df['Date'].dt.date <= date_range[1])
    ]
else:
    filtered_df = df[df['City'].isin(selected_cities)]

if page == "Dashboard":
    import page_dashboard
    page_dashboard.show(filtered_df)
elif page == "Charts":
    import page_charts
    page_charts.show(filtered_df, selected_pollutant)
elif page == "Statistics":
    import page_statistics
    page_statistics.show(filtered_df, selected_pollutant)
elif page == "Probability":
    import page_probability
    page_probability.show(filtered_df, selected_pollutant)
elif page == "Regression":
    import page_regression
    page_regression.show(filtered_df)
elif page == "Correlation":
    import page_correlation
    page_correlation.show(filtered_df)
