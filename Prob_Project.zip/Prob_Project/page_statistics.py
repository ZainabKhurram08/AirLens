import streamlit as st
import pandas as pd
import numpy as np
import plotly.figure_factory as ff
import plotly.express as px
from scipy import stats

def show(df, selected_pollutant):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:1.5rem;">📈 Analytical Statistics</h1>', unsafe_allow_html=True)
    if df.empty:
        st.warning("No data available for the selected filters.")
        return
    tab1, tab2 = st.tabs(["📋 Descriptive Summary", "📊 Distribution Analysis"])
    with tab1:
        with st.container(border=True):
            st.markdown(f'<h3 style="color:#475569; font-weight:700;">Statistical Indicators: {selected_pollutant}</h3>', unsafe_allow_html=True)
            stats_list = []
            for city in df['City'].unique():
                data = df[df['City'] == city][selected_pollutant].dropna()
                if len(data) < 2: continue
                mean = np.mean(data)
                std = np.std(data)
                n = len(data)
                ci = stats.t.interval(0.95, n-1, loc=mean, scale=std/np.sqrt(n))
                skew = stats.skew(data)
                if skew > 0.5: interpretation = "Right Skewed"
                elif skew < -0.5: interpretation = "Left Skewed"
                else: interpretation = "Symmetric"
                m = stats.mode(data, keepdims=True)
                mode_val = m.mode[0] if len(m.mode) > 0 else np.nan
                stats_list.append({
                    "City": city,
                    "Mean": round(mean, 2),
                    "Median": round(np.median(data), 2),
                    "Mode": round(mode_val, 2),
                    "Std Dev": round(std, 2),
                    "Min": round(np.min(data), 2),
                    "Max": round(np.max(data), 2),
                    "Variance": round(np.var(data), 2),
                    "Skewness": round(skew, 2),
                    "Kurtosis": round(stats.kurtosis(data), 2),
                    "Interpretation": interpretation,
                    "95% CI Lower": round(ci[0], 2),
                    "95% CI Upper": round(ci[1], 2)
                })
            if stats_list:
                stats_df = pd.DataFrame(stats_list)
                st.dataframe(stats_df.style.background_gradient(cmap='Pastel1', subset=['Mean', 'Median', 'Std Dev']), use_container_width=True)
            st.info("**Analytical Note:** The 95% Confidence Interval indicates that we can be 95% confident that the true population mean of the pollutant falls within this range.")
    with tab2:
        with st.container(border=True):
            st.markdown(f'<h3 style="color:#475569; font-weight:700;">{selected_pollutant} Distribution & Normal Fit</h3>', unsafe_allow_html=True)
            hist_data = [df[df['City'] == city][selected_pollutant].dropna().tolist() for city in df['City'].unique()]
            group_labels = df['City'].unique().tolist()
            fig = ff.create_distplot(hist_data, group_labels, bin_size=10, show_hist=True, show_rug=False,
                                     colors=px.colors.qualitative.Pastel)
            fig.update_layout(template="plotly_white", paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig, use_container_width=True)
            st.success("**Distribution Analysis:** A curve that closely resembles a bell shape indicates the data follows a Normal Distribution, validating the use of parametric statistical tests.")
