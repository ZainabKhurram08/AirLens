import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

def get_aqi_status(aqi):
    if aqi <= 50: return "Good", "#059669", "#d1fae5"
    elif aqi <= 100: return "Moderate", "#d97706", "#fef3c7"
    elif aqi <= 150: return "Unhealthy (Sensitive)", "#ea580c", "#ffedd5"
    elif aqi <= 200: return "Unhealthy", "#dc2626", "#fee2e2"
    elif aqi <= 300: return "Very Unhealthy", "#7c3aed", "#ede9fe"
    else: return "Hazardous", "#9f1239", "#ffe4e6"

def show(df):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:0;">🌍 AirLens Dashboard</h1>', unsafe_allow_html=True)
    st.markdown('<p style="color:#64748b; font-size:1.1rem; margin-bottom:2rem;">Live atmospheric analysis for urban hubs.</p>', unsafe_allow_html=True)

    if df.empty:
        st.warning("⚠️ No data available for the selected filters.")
        return

    cities = df['City'].unique()
    rows = [cities[i:i + 3] for i in range(0, len(cities), 3)]
    
    for row_cities in rows:
        cols = st.columns(3)
        for i, city in enumerate(row_cities):
            city_data = df[df['City'] == city].iloc[-1]
            history = df[df['City'] == city].tail(24)
            status, color, bg_color = get_aqi_status(city_data['AQI'])
            with cols[i]:
                with st.container(border=True):
                    st.markdown(f"""
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                            <span style="font-size: 1.2rem; font-weight: 700; color: #475569;">{city}</span>
                            <span class="status-pill" style="background-color: {bg_color}; color: {color}; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700;">{status}</span>
                        </div>
                        <h1 style="margin:0; font-size: 3rem; font-weight: 800; color: #1e293b; line-height: 1;">{int(city_data['AQI'])}</h1>
                        <p style="color: #94a3b8; font-size: 0.8rem; margin-top: 2px; font-weight: 600;">AQI INDEX</p>
                    """, unsafe_allow_html=True)
                    fig = px.line(history, x='Date', y='AQI', template="plotly_white")
                    fig.update_layout(
                        showlegend=False, xaxis_visible=False, yaxis_visible=False,
                        margin=dict(l=0, r=0, t=0, b=0), height=40,
                        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)'
                    )
                    fig.update_traces(line_color=color, line_width=3)
                    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False}, key=f"spark_{city}")

    st.markdown('<div style="margin-top:2rem;"></div>', unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700; margin-bottom:1rem;">📈 Regional Air Trends</h3>', unsafe_allow_html=True)
        fig_overview = px.line(df, x='Date', y='AQI', color='City', 
                               template="plotly_white",
                               color_discrete_sequence=px.colors.qualitative.Pastel)
        fig_overview.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_overview, use_container_width=True)
