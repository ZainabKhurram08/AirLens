import streamlit as st
import plotly.express as px

def show(df, selected_pollutant):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:1.5rem;">📊 Visual Insights</h1>', unsafe_allow_html=True)
    col1, col2 = st.columns([1.5, 1])
    with col1:
        with st.container(border=True):
            st.markdown('<h3 style="color:#475569; font-weight:700;">Urban AQI Comparison</h3>', unsafe_allow_html=True)
            avg_aqi = df.groupby('City')['AQI'].mean().reset_index()
            fig_bar = px.bar(avg_aqi, x='City', y='AQI', color='AQI',
                             template="plotly_white",
                             color_continuous_scale='Mint')
            fig_bar.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_bar, use_container_width=True)
    with col2:
        with st.container(border=True):
            st.markdown('<h3 style="color:#475569; font-weight:700;">Pollutant Share</h3>', unsafe_allow_html=True)
            pollutants = ['PM2.5', 'PM10', 'NO2', 'CO', 'O3']
            pollutant_sums = df[pollutants].mean()
            fig_pie = px.pie(values=pollutant_sums, names=pollutants, 
                             template="plotly_white",
                             hole=0.6,
                             color_discrete_sequence=px.colors.qualitative.Pastel)
            fig_pie.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_pie, use_container_width=True)
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">🤖 AI Data Insights</h3>', unsafe_allow_html=True)
        highest_aqi_city = df.groupby('City')['AQI'].mean().idxmax()
        highest_aqi_val = df.groupby('City')['AQI'].mean().max()
        dominant_pollutant = pollutant_sums.idxmax()
        st.info(f"**Key Finding 1:** The region with the highest average air pollution in this dataset is **{highest_aqi_city}** with an average AQI of **{highest_aqi_val:.1f}**.")
        st.success(f"**Key Finding 2:** Across all selected cities, **{dominant_pollutant}** makes up the largest share of the overall pollutant mix.")
        st.warning(f"**Actionable Recommendation:** To improve the probability models, consider gathering more localized data points for {highest_aqi_city}.")
    with st.container(border=True):
        st.markdown(f'<h3 style="color:#475569; font-weight:700;">Pollutant Focus: {selected_pollutant}</h3>', unsafe_allow_html=True)
        fig_trend = px.line(df, x='Date', y=selected_pollutant, color='City',
                            template="plotly_white",
                            color_discrete_sequence=px.colors.qualitative.Pastel1)
        fig_trend.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig_trend, use_container_width=True)
    csv = df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Export Dataset (CSV)",
        data=csv,
        file_name='airlens_data_export.csv',
        mime='text/csv',
    )
