import streamlit as st
import plotly.express as px

def show(df):
    st.markdown('<h1 style="color:#1e293b; font-weight:800; font-size:2.8rem; margin-bottom:1.5rem;">🔗 Pollutant Correlation</h1>', unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">Correlation Heatmap</h3>', unsafe_allow_html=True)
        pollutants = ['AQI', 'PM2.5', 'PM10', 'NO2', 'CO', 'O3']
        corr_matrix = df[pollutants].corr()
        fig_heat = px.imshow(corr_matrix, text_auto=".2f", 
                             color_continuous_scale='Purp',
                             template="plotly_white")
        fig_heat.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=20, b=20))
        st.plotly_chart(fig_heat, use_container_width=True)
    with st.container(border=True):
        st.markdown('<h3 style="color:#475569; font-weight:700;">🧠 Key Findings</h3>', unsafe_allow_html=True)
        corr_unstacked = corr_matrix.unstack().sort_values(ascending=False)
        top_corrs = corr_unstacked[corr_unstacked < 0.999].head(6)
        cols = st.columns(3)
        for i in range(0, len(top_corrs), 2):
            col_idx = i // 2
            pair = top_corrs.index[i]
            val = top_corrs.values[i]
            with cols[col_idx]:
                if val > 0.85:
                    st.error(f"**{pair[0]} ↔ {pair[1]}**\n\nCritical Association (r = {val:.2f})")
                elif val > 0.6:
                    st.warning(f"**{pair[0]} ↔ {pair[1]}**\n\nStrong Association (r = {val:.2f})")
                else:
                    st.info(f"**{pair[0]} ↔ {pair[1]}**\n\nModerate Association (r = {val:.2f})")
